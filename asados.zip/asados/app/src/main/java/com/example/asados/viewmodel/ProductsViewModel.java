package com.example.asados.viewmodel;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.ViewModel;
import com.example.asados.model.Product;
import com.example.asados.model.Resource;
import com.example.asados.repository.ProductsRepository;
import java.util.List;

public class ProductsViewModel extends ViewModel {

    private final ProductsRepository productsRepository;

    public ProductsViewModel() {
        this.productsRepository = new ProductsRepository();
    }

    public LiveData<Resource<List<Product>>> getProducts(int restaurantId) {
        return productsRepository.getProducts(restaurantId);
    }
}
