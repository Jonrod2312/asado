package com.example.asados;

import android.content.Intent;
import android.os.Bundle;


import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.os.Bundle;
import android.widget.FrameLayout;
import com.example.asados.R;
import com.example.asados.fragment.HomeFragment;
import com.example.asados.fragment.OrdersFragment;
import com.example.asados.fragment.ProfileFragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

public class MainActivity extends AppCompatActivity {

    private FrameLayout container;
    private BottomNavigationView bottomNav;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        container = findViewById(R.id.container);
        bottomNav = findViewById(R.id.bottomNav);

        bottomNav.setOnItemSelectedListener(item -> {
            Fragment selectedFragment = null;
            if (item.getItemId() == R.id.activity_main) {
                selectedFragment = new HomeFragment();
            } else if (item.getItemId() == R.id.activity_orders) {
                selectedFragment = new OrdersFragment();
            } else if (item.getItemId() == R.id.fragment_profile) {
                selectedFragment = new ProfileFragment();
            }
            if (selectedFragment != null) {
                getSupportFragmentManager().beginTransaction().replace(R.id.container, selectedFragment).commit();
                return true;
            }
            return false;
        });

        // Carga el fragmento de inicio por defecto
        if (savedInstanceState == null) {
            bottomNav.setSelectedItemId(R.id.activity_main);
        }

        findViewById(R.id.btnProfile).setOnClickListener(v ->
                startActivity(new Intent(this, ProfileActivity.class)));

        findViewById(R.id.btnOrder).setOnClickListener(v ->
                startActivity(new Intent(this, OrderActivity.class)));


        findViewById(R.id.btnDeliveryDetail).setOnClickListener(v ->
                startActivity(new Intent(this, DeliveryDetailActivity.class)));

        findViewById(R.id.btnRegister).setOnClickListener(v ->
                startActivity(new Intent(this, RegisterActivity.class)));

    }


}
