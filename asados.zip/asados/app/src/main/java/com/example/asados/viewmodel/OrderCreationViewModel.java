package com.example.asados.viewmodel;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.ViewModel;
import com.example.asados.model.Order;
import com.example.asados.model.OrderRequest;
import com.example.asados.model.Product;
import com.example.asados.model.Resource;
import com.example.asados.repository.OrdersRepository;
import java.util.ArrayList;
import java.util.List;

public class OrderCreationViewModel extends ViewModel {

    private final OrdersRepository ordersRepository;
    private final List<Product> cart = new ArrayList<>();

    public OrderCreationViewModel() {
        this.ordersRepository = new OrdersRepository();
    }

    public void addProductToCart(Product product) {
        cart.add(product);
    }

    public List<Product> getCart() {
        return cart;
    }

    public LiveData<Resource<Order>> createOrder(OrderRequest orderRequest) {
        return ordersRepository.createOrder(orderRequest);
    }
}
