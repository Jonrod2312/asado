package com.example.asados.api;

import com.example.asados.model.Order;
import com.example.asados.model.Product;
import com.example.asados.model.User;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.PATCH;
import retrofit2.http.POST;
import retrofit2.http.Path;

/**
 * Interfaz que define los endpoints para la API de Asados Steaks.
 * Usada por Retrofit para generar las llamadas HTTP.
 */
public interface ApiService {

    @POST("auth/login")
    Call<User> login(@Body User user);

    @POST("auth/register")
    Call<User> register(@Body User user);

    @GET("products")
    Call<List<Product>> getProducts();

    @POST("orders")
    Call<Order> createOrder(@Body Order order);

    @GET("orders")
    Call<List<Order>> getOrders();

    @GET("orders/{id}")
    Call<Order> getOrderById(@Path("id") String orderId);

    @PATCH("orders/{id}/status")
    Call<Void> updateOrderStatus(@Path("id") String orderId, @Body String status);
}

