package com.example.asados;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.example.asados.R;
import com.example.asados.api.ApiClient;
import com.example.asados.api.ApiService;
import com.example.asados.model.Order;
import com.example.asados.model.Location;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.android.material.button.MaterialButton;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Actividad para mostrar el detalle de una entrega.
 * Muestra un mapa con la ruta y botones para gestionar el estado del pedido.
 */
public class DeliveryDetailActivity extends AppCompatActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private String orderId;
    private MaterialButton btnAccept;
    private MaterialButton btnDelivered;
    private ApiService apiService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delivery_detail);

        // Inicializar vistas
        btnAccept = findViewById(R.id.btnAccept);
        btnDelivered = findViewById(R.id.btnDelivered);

        // Obtener el ID del pedido del Intent
        Intent intent = getIntent();
        if (intent != null && intent.hasExtra("orderId")) {
            orderId = intent.getStringExtra("orderId");
        }

        // Inicializar el servicio de la API usando el ApiClient
        apiService = ApiClient.getClient().create(ApiService.class);

        // Configurar el mapa
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }

        // Configurar listeners de los botones
        btnAccept.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                acceptDelivery();
            }
        });

        btnDelivered.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                markAsDelivered();
            }
        });
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        // Si tenemos un orderId válido, obtenemos la ruta y la mostramos en el mapa.
        if (orderId != null) {
            getAndDisplayRoute(orderId);
        }
    }

    /**
     * Obtiene los detalles de la orden y muestra la ruta en el mapa.
     *
     * @param id El ID del pedido a buscar.
     */
    private void getAndDisplayRoute(String id) {
        Call<Order> call = apiService.getOrderById(id);
        call.enqueue(new Callback<Order>() {
            @Override
            public void onResponse(Call<Order> call, Response<Order> response) {
                if (response.isSuccessful() && response.body() != null) {
                    Order order = response.body();

                    // Se obtienen las ubicaciones de origen y destino del objeto Order
                    Location originLocation = order.getOrigin();
                    Location destinationLocation = order.getDestination();

                    // Se verifica que las ubicaciones existan antes de usarlas
                    if (originLocation != null && destinationLocation != null) {
                        // Se obtienen las coordenadas LatLng
                        LatLng origin = new LatLng(originLocation.getLatitude(), originLocation.getLongitude());
                        LatLng destination = new LatLng(destinationLocation.getLatitude(), destinationLocation.getLongitude());

                        // Agregar marcadores al mapa
                        mMap.addMarker(new MarkerOptions().position(origin).title("Origen"));
                        mMap.addMarker(new MarkerOptions().position(destination).title("Destino"));

                        // Dibujar una línea entre los puntos
                        mMap.addPolyline(new PolylineOptions().add(origin, destination).color(0xFFFF0000));
                    }
                } else {
                    Toast.makeText(DeliveryDetailActivity.this, "No se pudo cargar el pedido", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Order> call, Throwable t) {
                Toast.makeText(DeliveryDetailActivity.this, "Error de red: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    /**
     * Llama a la API para cambiar el estado del pedido a 'in_progress'.
     */
    private void acceptDelivery() {
        if (orderId == null) {
            Toast.makeText(this, "ID de pedido no encontrado", Toast.LENGTH_SHORT).show();
            return;
        }

        Call<Void> call = apiService.updateOrderStatus(orderId, "in_progress");
        call.enqueue(new Callback<Void>() {
            @Override
            public void onResponse(Call<Void> call, Response<Void> response) {
                if (response.isSuccessful()) {
                    Toast.makeText(DeliveryDetailActivity.this, "Pedido aceptado. ¡A entregar!", Toast.LENGTH_SHORT).show();
                    // Opcional: Desactivar el botón 'Aceptar' y activar el 'Entregado'
                    btnAccept.setEnabled(false);
                    btnDelivered.setEnabled(true);
                } else {
                    Toast.makeText(DeliveryDetailActivity.this, "Error al aceptar el pedido", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Void> call, Throwable t) {
                Toast.makeText(DeliveryDetailActivity.this, "Error de red: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    /**
     * Llama a la API para cambiar el estado del pedido a 'delivered'.
     */
    private void markAsDelivered() {
        if (orderId == null) {
            Toast.makeText(this, "ID de pedido no encontrado", Toast.LENGTH_SHORT).show();
            return;
        }

        Call<Void> call = apiService.updateOrderStatus(orderId, "delivered");
        call.enqueue(new Callback<Void>() {
            @Override
            public void onResponse(Call<Void> call, Response<Void> response) {
                if (response.isSuccessful()) {
                    Toast.makeText(DeliveryDetailActivity.this, "Pedido entregado con éxito.", Toast.LENGTH_SHORT).show();
                    // Opcional: Cerrar la actividad y volver a la lista de pedidos
                    finish();
                } else {
                    Toast.makeText(DeliveryDetailActivity.this, "Error al marcar como entregado", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Void> call, Throwable t) {
                Toast.makeText(DeliveryDetailActivity.this, "Error de red: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
