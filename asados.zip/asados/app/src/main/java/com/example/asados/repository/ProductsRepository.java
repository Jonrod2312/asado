package com.example.asados.repository;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import com.example.asados.api.ApiClient;
import com.example.asados.api.ProductService;
import com.example.asados.model.Product;
import com.example.asados.model.Resource;
import java.util.List;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ProductsRepository {

    private final ProductService productService;

    public ProductsRepository() {
        this.productService = ApiClient.getClient().create(ProductService.class);
    }

    public LiveData<Resource<List<Product>>> getProducts(int restaurantId) {
        MutableLiveData<Resource<List<Product>>> data = new MutableLiveData<>();
        data.setValue(Resource.loading(null));

        productService.getProducts(restaurantId).enqueue(new Callback<List<Product>>() {
            @Override
            public void onResponse(Call<List<Product>> call, Response<List<Product>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    data.setValue(Resource.success(response.body()));
                } else {
                    data.setValue(Resource.error("Error al cargar los productos.", null));
                }
            }

            @Override
            public void onFailure(Call<List<Product>> call, Throwable t) {
                data.setValue(Resource.error(t.getMessage(), null));
            }
        });
        return data;
    }
}

