package com.example.asados;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.example.asados.R;
import com.example.asados.model.User;
import com.example.asados.util.Prefs;
import com.example.asados.viewmodel.AuthViewModel;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

public class RegisterActivity extends AppCompatActivity {

    private EditText etName, etEmail, etPassword;
    private Button btnRegister;
    private AuthViewModel authViewModel;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        etName = findViewById(R.id.etName);
        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        btnRegister = findViewById(R.id.btnRegister);
        authViewModel = new ViewModelProvider(this).get(AuthViewModel.class);

        btnRegister.setOnClickListener(v -> {
            String name = etName.getText().toString();
            String email = etEmail.getText().toString();
            String password = etPassword.getText().toString();
            User user = new User("", name, email, password, null);

            authViewModel.register(user).observe(this, resource -> {
                if (resource != null) {
                    if (resource.getStatus() == com.example.asados.model.Resource.Status.SUCCESS) {
                        if (resource.getData() != null && resource.getData().getUser() != null) {
                            User registeredUser = resource.getData().getUser();
                            Prefs.saveAuthToken(this, registeredUser.getToken());
                            Prefs.saveUserId(this, registeredUser.getId());
                            Toast.makeText(this, "Registro exitoso", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(this, MainActivity.class));
                            finish();
                        }
                    } else if (resource.getMessage() != null) {
                        Toast.makeText(this, resource.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            });
        });
    }
}
