package com.example.asados.repository;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import com.example.asados.api.ApiClient;
import com.example.asados.api.DeliveryService;
import com.example.asados.model.Order;
import com.example.asados.model.Resource;
import java.util.List;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DeliveryRepository {

    private final DeliveryService deliveryService;
    private final String authToken = "YOUR_AUTH_TOKEN"; // TODO: Reemplazar con el token real del usuario

    public DeliveryRepository() {
        this.deliveryService = ApiClient.getClient().create(DeliveryService.class);
    }

    public LiveData<Resource<List<Order>>> getAvailableOrders() {
        MutableLiveData<Resource<List<Order>>> data = new MutableLiveData<>();
        data.setValue(Resource.loading(null));

        deliveryService.getAvailableOrders(authToken).enqueue(new Callback<List<Order>>() {
            @Override
            public void onResponse(Call<List<Order>> call, Response<List<Order>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    data.setValue(Resource.success(response.body()));
                } else {
                    data.setValue(Resource.error("Error al cargar pedidos disponibles.", null));
                }
            }

            @Override
            public void onFailure(Call<List<Order>> call, Throwable t) {
                data.setValue(Resource.error(t.getMessage(), null));
            }
        });
        return data;
    }
}
