package com.example.asados.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import com.example.asados.R;
import com.example.asados.model.Order;
import com.example.asados.adapter.OrdersAdapter;
import com.example.asados.viewmodel.OrdersViewModel;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class OrdersFragment extends Fragment {

    private OrdersViewModel ordersViewModel;
    private RecyclerView rvOrders;
    private OrdersAdapter ordersAdapter;
    private final List<Order> orderList = new ArrayList<>();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_orders, container, false);
        rvOrders = view.findViewById(R.id.rvOrders);
        rvOrders.setLayoutManager(new LinearLayoutManager(getContext()));
        ordersAdapter = new OrdersAdapter(getContext(), orderList);
        rvOrders.setAdapter(ordersAdapter);
        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        ordersViewModel = new ViewModelProvider(this).get(OrdersViewModel.class);
        observeOrders();
    }

    private void observeOrders() {
        ordersViewModel.getMyOrders().observe(getViewLifecycleOwner(), resource -> {
            if (resource != null) {
                switch (resource.getStatus()) {
                    case LOADING:
                        Toast.makeText(getContext(), "Cargando pedidos...", Toast.LENGTH_SHORT).show();
                        break;
                    case SUCCESS:
                        if (resource.getData() != null) {
                            orderList.clear();
                            orderList.addAll(resource.getData());
                            ordersAdapter.notifyDataSetChanged();
                        }
                        break;
                    case ERROR:
                        Toast.makeText(getContext(), "Error: " + resource.getMessage(), Toast.LENGTH_LONG).show();
                        break;
                }
            }
        });
    }
}
