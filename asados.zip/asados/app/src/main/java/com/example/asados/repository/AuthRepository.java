package com.example.asados.repository;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import com.example.asados.api.ApiClient;
import com.example.asados.api.AuthService;
import com.example.asados.model.AuthResponse;
import com.example.asados.model.Resource;
import com.example.asados.model.User;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AuthRepository {

    private final AuthService authService;

    public AuthRepository() {
        authService = ApiClient.getClient().create(AuthService.class);
    }

    public LiveData<Resource<AuthResponse>> login(User user) {
        MutableLiveData<Resource<AuthResponse>> data = new MutableLiveData<>();
        data.setValue(Resource.loading(null));

        authService.login(user).enqueue(new Callback<AuthResponse>() {
            @Override
            public void onResponse(Call<AuthResponse> call, Response<AuthResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    // TODO: Guardar el token del usuario en SharedPreferences
                    data.setValue(Resource.success(response.body()));
                } else {
                    data.setValue(Resource.error("Credenciales inválidas.", null));
                }
            }

            @Override
            public void onFailure(Call<AuthResponse> call, Throwable t) {
                data.setValue(Resource.error(t.getMessage(), null));
            }
        });
        return data;
    }

    public LiveData<Resource<AuthResponse>> register(User user) {
        MutableLiveData<Resource<AuthResponse>> data = new MutableLiveData<>();
        data.setValue(Resource.loading(null));

        authService.register(user).enqueue(new Callback<AuthResponse>() {
            @Override
            public void onResponse(Call<AuthResponse> call, Response<AuthResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    data.setValue(Resource.success(response.body()));
                } else {
                    data.setValue(Resource.error("Error al registrarse.", null));
                }
            }

            @Override
            public void onFailure(Call<AuthResponse> call, Throwable t) {
                data.setValue(Resource.error(t.getMessage(), null));
            }
        });
        return data;
    }
}