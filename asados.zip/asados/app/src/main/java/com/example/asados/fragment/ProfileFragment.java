package com.example.asados.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.example.asados.R;
import com.example.asados.model.User;
import com.example.asados.util.Prefs;
import com.example.asados.viewmodel.ProfileViewModel;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

public class ProfileFragment extends Fragment {

    private ProfileViewModel profileViewModel;
    private EditText etName, etPhone;
    private Button btnSave;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_profile, container, false);
        etName = view.findViewById(R.id.etName);
        etPhone = view.findViewById(R.id.etPhone);
        btnSave = view.findViewById(R.id.btnSave);
        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        profileViewModel = new ViewModelProvider(this).get(ProfileViewModel.class);

        // Cambiamos a String porque Firebase UID es String
        String userId = Prefs.getUserId(getContext());
        if (userId != null && !userId.isEmpty()) {
            profileViewModel.getUserProfile(userId).observe(getViewLifecycleOwner(), resource -> {
                if (resource != null && resource.getData() != null) {
                    etName.setText(resource.getData().getName());
                    etPhone.setText(resource.getData().getPhone());
                } else if (resource != null && resource.getMessage() != null) {
                    Toast.makeText(getContext(), resource.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });
        }

        btnSave.setOnClickListener(v -> {
            String name = etName.getText().toString();
            String phone = etPhone.getText().toString();

            // Usamos String para el ID
            User user = new User(userId, name, null, phone, null);

            profileViewModel.updateUserProfile(userId, user).observe(getViewLifecycleOwner(), resource -> {
                if (resource != null) {
                    if (resource.getStatus() == com.example.asados.model.Resource.Status.SUCCESS) {
                        Toast.makeText(getContext(), "Perfil actualizado", Toast.LENGTH_SHORT).show();
                    } else if (resource.getMessage() != null) {
                        Toast.makeText(getContext(), resource.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            });
        });
    }
}
