package com.example.asados.repository;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import com.example.asados.api.ApiClient;
import com.example.asados.api.OrderService;
import com.example.asados.model.Order;
import com.example.asados.model.OrderRequest;
import com.example.asados.model.Resource;
import java.util.List;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class OrdersRepository {

    private final OrderService orderService;
    private final String authToken = "YOUR_AUTH_TOKEN"; // TODO: Reemplazar con el token real del usuario

    public OrdersRepository() {
        this.orderService = ApiClient.getClient().create(OrderService.class);
    }

    public LiveData<Resource<List<Order>>> getMyOrders() {
        MutableLiveData<Resource<List<Order>>> data = new MutableLiveData<>();
        data.setValue(Resource.loading(null));

        orderService.getMyOrders(authToken).enqueue(new Callback<List<Order>>() {
            @Override
            public void onResponse(Call<List<Order>> call, Response<List<Order>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    data.setValue(Resource.success(response.body()));
                } else {
                    data.setValue(Resource.error("Error al cargar tus pedidos.", null));
                }
            }

            @Override
            public void onFailure(Call<List<Order>> call, Throwable t) {
                data.setValue(Resource.error(t.getMessage(), null));
            }
        });
        return data;
    }

    public LiveData<Resource<Order>> createOrder(OrderRequest orderRequest) {
        MutableLiveData<Resource<Order>> data = new MutableLiveData<>();
        data.setValue(Resource.loading(null));

        orderService.createOrder(authToken, orderRequest).enqueue(new Callback<Order>() {
            @Override
            public void onResponse(Call<Order> call, Response<Order> response) {
                if (response.isSuccessful() && response.body() != null) {
                    data.setValue(Resource.success(response.body()));
                } else {
                    data.setValue(Resource.error("Error al crear el pedido.", null));
                }
            }

            @Override
            public void onFailure(Call<Order> call, Throwable t) {
                data.setValue(Resource.error(t.getMessage(), null));
            }
        });
        return data;
    }

    public LiveData<Resource<Void>> acceptOrder(int orderId) {
        MutableLiveData<Resource<Void>> data = new MutableLiveData<>();
        data.setValue(Resource.loading(null));

        orderService.acceptOrder(authToken, orderId).enqueue(new Callback<Void>() {
            @Override
            public void onResponse(Call<Void> call, Response<Void> response) {
                if (response.isSuccessful()) {
                    data.setValue(Resource.success(null));
                } else {
                    data.setValue(Resource.error("Error al aceptar el pedido.", null));
                }
            }

            @Override
            public void onFailure(Call<Void> call, Throwable t) {
                data.setValue(Resource.error(t.getMessage(), null));
            }
        });
        return data;
    }
}
