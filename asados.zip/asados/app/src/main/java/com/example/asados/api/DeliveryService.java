package com.example.asados.api;

import com.example.asados.model.Order;
import java.util.List;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Header;

public interface DeliveryService {
    @GET("api/delivery/available-orders")
    Call<List<Order>> getAvailableOrders(@Header("Authorization") String token);
}