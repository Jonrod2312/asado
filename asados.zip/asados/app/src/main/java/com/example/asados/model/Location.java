package com.example.asados.model;

import com.google.gson.annotations.SerializedName;

import com.google.gson.annotations.SerializedName;

/**
 * Clase de modelo para representar coordenadas de latitud y longitud.
 */
public class Location {
    @SerializedName("lat")
    private double latitude;
    @SerializedName("lng")
    private double longitude;

    public Location(double latitude, double longitude) {
        this.latitude = latitude;
        this.longitude = longitude;
    }

    public double getLatitude() {
        return latitude;
    }

    public double getLongitude() {
        return longitude;
    }
}
