package com.example.asados.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import com.example.asados.R;
import com.example.asados.model.Product;
import com.example.asados.OrderActivity;
import com.example.asados.adapter.ProductsAdapter;
import com.example.asados.viewmodel.ProductsViewModel;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class HomeFragment extends Fragment {

    private ProductsViewModel productsViewModel;
    private RecyclerView rvProducts;
    private ProductsAdapter productsAdapter;
    private final List<Product> productList = new ArrayList<>();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);
        rvProducts = view.findViewById(R.id.rvProducts);
        rvProducts.setLayoutManager(new LinearLayoutManager(getContext()));
        productsAdapter = new ProductsAdapter(getContext(), productList);
        rvProducts.setAdapter(productsAdapter);
        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        productsViewModel = new ViewModelProvider(this).get(ProductsViewModel.class);
        observeProducts();

        productsAdapter.setOnProductClickListener(product -> {
            // TODO: Añadir lógica para agregar el producto al carrito
            Toast.makeText(getContext(), product.getName() + " añadido al carrito", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(getContext(), OrderActivity.class);
            // Pasar el producto o la información necesaria a la actividad del carrito
            startActivity(intent);
        });
    }

    private void observeProducts() {
        productsViewModel.getProducts(1).observe(getViewLifecycleOwner(), resource -> {
            if (resource != null) {
                switch (resource.getStatus()) {
                    case LOADING:
                        Toast.makeText(getContext(), "Cargando productos...", Toast.LENGTH_SHORT).show();
                        break;
                    case SUCCESS:
                        if (resource.getData() != null) {
                            productList.clear();
                            productList.addAll(resource.getData());
                            productsAdapter.notifyDataSetChanged();
                        }
                        break;
                    case ERROR:
                        Toast.makeText(getContext(), "Error: " + resource.getMessage(), Toast.LENGTH_LONG).show();
                        break;
                }
            }
        });
    }
}