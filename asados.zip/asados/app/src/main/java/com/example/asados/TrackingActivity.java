package com.example.asados;

import android.os.Bundle;
import android.widget.Button;
import com.example.asados.R;
import com.example.asados.viewmodel.TrackingViewModel;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

public class TrackingActivity extends AppCompatActivity {

    private TrackingViewModel trackingViewModel;
    private Button btnAccept, btnDelivered;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delivery_detail);

        btnAccept = findViewById(R.id.btnAccept);
        btnDelivered = findViewById(R.id.btnDelivered);

        trackingViewModel = new ViewModelProvider(this).get(TrackingViewModel.class);

        btnAccept.setOnClickListener(v -> {
            // TODO: Obtener el ID del pedido y la lógica de aceptación.
        });

        btnDelivered.setOnClickListener(v -> {
            // TODO: Obtener el ID del pedido y la lógica de entrega.
        });
    }
}
