package com.example.asados.viewmodel;


import androidx.lifecycle.LiveData;
import androidx.lifecycle.ViewModel;
import com.example.asados.model.Order;
import com.example.asados.model.Resource;
import com.example.asados.repository.DeliveryRepository;
import com.example.asados.repository.OrdersRepository;
import java.util.List;

public class TrackingViewModel extends ViewModel {

    private final DeliveryRepository deliveryRepository;
    private final OrdersRepository ordersRepository;

    public TrackingViewModel() {
        this.deliveryRepository = new DeliveryRepository();
        this.ordersRepository = new OrdersRepository();
    }

    public LiveData<Resource<List<Order>>> getAvailableOrders() {
        return deliveryRepository.getAvailableOrders();
    }

    public LiveData<Resource<Void>> acceptOrder(int orderId) {
        return ordersRepository.acceptOrder(orderId);
    }
}