package com.example.asados;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.example.asados.R;
import com.example.asados.model.User;
import com.example.asados.util.Prefs;
import com.example.asados.viewmodel.ProfileViewModel;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

public class ProfileActivity extends AppCompatActivity {

    private ProfileViewModel profileViewModel;
    private EditText etName, etPhone;
    private Button btnSave;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        etName = findViewById(R.id.etName);
        etPhone = findViewById(R.id.etPhone);

        btnSave = findViewById(R.id.btnSave);
        profileViewModel = new ViewModelProvider(this).get(ProfileViewModel.class);

        String userId = Prefs.getUserId(this);
        if (false) {
            profileViewModel.getUserProfile(userId).observe(this, resource -> {
                if (resource != null && resource.getData() != null) {
                    etName.setText(resource.getData().getName());
                    etPhone.setText(resource.getData().getPhone());
                } else if (resource != null && resource.getMessage() != null) {
                    Toast.makeText(this, resource.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });
        }

        btnSave.setOnClickListener(v -> {
            String name = etName.getText().toString();
            String phone = etPhone.getText().toString();
            User user = new User(userId, name, null, phone, null);

            profileViewModel.updateUserProfile(userId, user).observe(this, resource -> {
                if (resource != null) {
                    if (resource.getStatus() == com.example.asados.model.Resource.Status.SUCCESS) {
                        Toast.makeText(this, "Perfil actualizado", Toast.LENGTH_SHORT).show();
                        finish();
                    } else if (resource.getMessage() != null) {
                        Toast.makeText(this, resource.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            });
        });
    }
}
