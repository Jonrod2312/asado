package com.example.asados.viewmodel;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.ViewModel;
import com.example.asados.model.AuthResponse;
import com.example.asados.model.Resource;
import com.example.asados.model.User;
import com.example.asados.repository.AuthRepository;

public class AuthViewModel extends ViewModel {

    private final AuthRepository authRepository;

    public AuthViewModel() {
        this.authRepository = new AuthRepository();
    }

    public LiveData<Resource<AuthResponse>> login(User user) {
        return authRepository.login(user);
    }

    public LiveData<Resource<AuthResponse>> register(User user) {
        return authRepository.register(user);
    }
}
