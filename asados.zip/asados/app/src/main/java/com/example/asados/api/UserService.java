package com.example.asados.api;

import com.example.asados.model.User;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.PUT;
import retrofit2.http.Path;

public interface UserService {
    @GET("api/users/{id}")
    Call<User> getUserProfile(@Header("Authorization") String token, @Path("id") int userId);

    @PUT("api/users/{id}")
    Call<User> updateUserProfile(@Header("Authorization") String token, @Path("id") int userId, @Body User user);
}