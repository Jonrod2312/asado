package com.example.asados.api;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;


import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * Clase de utilidad para crear y proporcionar una instancia de Retrofit.
 * Sigue el patrón Singleton para asegurar que solo haya una instancia del cliente HTTP
 * durante toda la vida de la aplicación.
 */
public class ApiClient {

    // Variable estática para la instancia de Retrofit
    private static Retrofit retrofit = null;

    // URL base de la API, definida como una constante para fácil gestión
    private static final String BASE_URL = "http://200.107.122.45:3000/";

    /**
     * Devuelve una instancia de Retrofit. Si la instancia no existe, la crea.
     * @return La instancia de Retrofit configurada.
     */
    public static Retrofit getClient() {
        // Si la instancia es nula, significa que aún no ha sido creada
        if (retrofit == null) {
            retrofit = new Retrofit.Builder()
                    // Establece la URL base para todas las llamadas
                    .baseUrl(BASE_URL)
                    // Agrega el convertidor GSON para serializar y deserializar objetos
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();
        }
        // Devuelve la instancia existente (o recién creada)
        return retrofit;
    }
}