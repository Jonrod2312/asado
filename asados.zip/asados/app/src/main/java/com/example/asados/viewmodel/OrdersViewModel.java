package com.example.asados.viewmodel;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.ViewModel;
import com.example.asados.model.Order;
import com.example.asados.model.Resource;
import com.example.asados.repository.OrdersRepository;
import java.util.List;

public class OrdersViewModel extends ViewModel {

    private final OrdersRepository ordersRepository;

    public OrdersViewModel() {
        this.ordersRepository = new OrdersRepository();
    }

    public LiveData<Resource<List<Order>>> getMyOrders() {
        return ordersRepository.getMyOrders();
    }
}