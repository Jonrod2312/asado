package com.example.asados.repository;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import com.example.asados.api.ApiClient;
import com.example.asados.api.UserService;
import com.example.asados.model.Resource;
import com.example.asados.model.User;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class UserRepository {

    private final UserService userService;
    private final String authToken = "YOUR_AUTH_TOKEN"; // TODO: Reemplazar con el token real del usuario

    public UserRepository() {
        this.userService = ApiClient.getClient().create(UserService.class);
    }

    public LiveData<Resource<User>> getUserProfile(int userId) {
        MutableLiveData<Resource<User>> data = new MutableLiveData<>();
        data.setValue(Resource.loading(null));

        userService.getUserProfile(authToken, userId).enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                if (response.isSuccessful() && response.body() != null) {
                    data.setValue(Resource.success(response.body()));
                } else {
                    data.setValue(Resource.error("Error al cargar el perfil.", null));
                }
            }

            @Override
            public void onFailure(Call<User> call, Throwable t) {
                data.setValue(Resource.error(t.getMessage(), null));
            }
        });
        return data;
    }

    public LiveData<Resource<User>> updateUserProfile(int userId, User user) {
        MutableLiveData<Resource<User>> data = new MutableLiveData<>();
        data.setValue(Resource.loading(null));

        userService.updateUserProfile(authToken, userId, user).enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                if (response.isSuccessful() && response.body() != null) {
                    data.setValue(Resource.success(response.body()));
                } else {
                    data.setValue(Resource.error("Error al actualizar el perfil.", null));
                }
            }

            @Override
            public void onFailure(Call<User> call, Throwable t) {
                data.setValue(Resource.error(t.getMessage(), null));
            }
        });
        return data;
    }
}
