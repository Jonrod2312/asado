package com.example.asados.model;

import com.google.gson.annotations.SerializedName;
import java.util.List;

public class OrderRequest {
    @SerializedName("userId")
    private int userId;
    @SerializedName("products")
    private List<Product> products;
    @SerializedName("location")
    private Location location;

    public OrderRequest(int userId, List<Product> products, Location location) {
        this.userId = userId;
        this.products = products;
        this.location = location;
    }

    public int getUserId() {
        return userId;
    }

    public List<Product> getProducts() {
        return products;
    }

    public Location getLocation() {
        return location;
    }
}
