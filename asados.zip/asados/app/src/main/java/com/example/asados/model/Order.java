package com.example.asados.model;

import com.google.gson.annotations.SerializedName;
import java.util.List;

/**
 * Clase de modelo para representar un pedido.
 * Incluye datos como el ID, el estado, el total, los productos
 * y las ubicaciones de origen y destino para la entrega.
 */
public class Order {
    @SerializedName("id")
    private int id;
    @SerializedName("userId")
    private int userId;
    @SerializedName("status")
    private String status;
    @SerializedName("total")
    private double total;
    @SerializedName("products")
    private List<Product> products;

    // Nuevos campos para las coordenadas de origen y destino
    @SerializedName("origin")
    private Location origin;
    @SerializedName("destination")
    private Location destination;

    public Order(int id, int userId, String status, double total, List<Product> products, Location origin, Location destination) {
        this.id = id;
        this.userId = userId;
        this.status = status;
        this.total = total;
        this.products = products;
        this.origin = origin;
        this.destination = destination;
    }

    public int getId() {
        return id;
    }

    public int getUserId() {
        return userId;
    }

    public String getStatus() {
        return status;
    }

    public double getTotal() {
        return total;
    }

    public List<Product> getProducts() {
        return products;
    }

    // Nuevos métodos getters para las ubicaciones
    public Location getOrigin() {
        return origin;
    }

    public Location getDestination() {
        return destination;
    }
}
