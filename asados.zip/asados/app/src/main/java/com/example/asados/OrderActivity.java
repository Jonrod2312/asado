package com.example.asados;

import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;
import com.example.asados.R;
import com.example.asados.model.OrderRequest;
import com.example.asados.model.Product;
import com.example.asados.util.Prefs;
import com.example.asados.viewmodel.OrderCreationViewModel;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.asados.adapter.ProductsAdapter;
import java.util.List;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;


public class OrderActivity extends AppCompatActivity {

    private OrderCreationViewModel viewModel;
    private RecyclerView rvCart;
    private Button btnPlaceOrder;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order);

        viewModel = new ViewModelProvider(this).get(OrderCreationViewModel.class);
        rvCart = findViewById(R.id.rvCart);
        btnPlaceOrder = findViewById(R.id.btnPlaceOrder);

        rvCart.setLayoutManager(new LinearLayoutManager(this));
        List<Product> cart = viewModel.getCart();
        ProductsAdapter adapter = new ProductsAdapter(this, cart);
        rvCart.setAdapter(adapter);

        btnPlaceOrder.setOnClickListener(v -> {
            // TODO: Crear una instancia de Location con la ubicación del usuario
            // Por ahora, usamos valores de ejemplo.
            // Location userLocation = new Location(12.345, 67.890);
            // int userId = Prefs.getUserId(this);
            // OrderRequest orderRequest = new OrderRequest(userId, cart, userLocation);

            // viewModel.createOrder(orderRequest).observe(this, resource -> {
            //    if (resource.getStatus() == com.asados.model.Resource.Status.SUCCESS) {
            //        Toast.makeText(this, "Pedido creado con éxito!", Toast.LENGTH_SHORT).show();
            //        finish();
            //    } else if (resource.getMessage() != null) {
            //        Toast.makeText(this, resource.getMessage(), Toast.LENGTH_SHORT).show();
            //    }
            // });

            Toast.makeText(this, "Lógica de pedido en desarrollo...", Toast.LENGTH_SHORT).show();
        });
    }
}
