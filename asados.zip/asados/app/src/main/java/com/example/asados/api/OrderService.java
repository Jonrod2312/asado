package com.example.asados.api;

import com.example.asados.model.Order;
import com.example.asados.model.OrderRequest;
import java.util.List;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;
import retrofit2.http.Header;

public interface OrderService {
    @GET("api/orders/my-orders")
    Call<List<Order>> getMyOrders(@Header("Authorization") String token);

    @POST("api/orders/create")
    Call<Order> createOrder(@Header("Authorization") String token, @Body OrderRequest orderRequest);

    @POST("api/orders/{id}/accept")
    Call<Void> acceptOrder(@Header("Authorization") String token, @Path("id") int orderId);

    @POST("api/orders/{id}/delivered")
    Call<Void> deliveredOrder(@Header("Authorization") String token, @Path("id") int orderId);
}
