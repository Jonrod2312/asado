package com.example.asados.api;

import com.example.asados.model.AuthResponse;
import com.example.asados.model.User;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface AuthService {
    @POST("api/auth/login")
    Call<AuthResponse> login(@Body User user);

    @POST("api/auth/register")
    Call<AuthResponse> register(@Body User user);
}