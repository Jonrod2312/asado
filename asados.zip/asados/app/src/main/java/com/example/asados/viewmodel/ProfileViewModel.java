package com.example.asados.viewmodel;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.ViewModel;
import com.example.asados.model.Resource;
import com.example.asados.model.User;
import com.example.asados.repository.UserRepository;

public class ProfileViewModel extends ViewModel {

    private final UserRepository userRepository;

    public ProfileViewModel() {
        this.userRepository = new UserRepository();
    }

    // Cambiamos int a String
    public LiveData<Resource<User>> getUserProfile(String userId) {
        return userRepository.getUserProfile(Integer.parseInt(userId));
    }

    public LiveData<Resource<User>> updateUserProfile(String userId, User user) {
        return userRepository.updateUserProfile(Integer.parseInt(userId), user);
    }
}

